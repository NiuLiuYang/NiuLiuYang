var exec = require('cordova/exec');

module.exports.startServiceOnSuccess=function(success, error, msg) {
    exec(success, error, "IrompPlugin", "startServiceOnSuccess", [msg]);
};

module.exports.stopServiceOnSuccess=function(success, error, msg) {
    exec(success, error, "IrompPlugin", "stopServiceOnSuccess", [msg]);
};

module.exports.setStartSign=function(success, error, msg) {
    exec(success, error, "IrompPlugin", "setStartSign", [msg]);
};

module.exports.setStopSign=function(success, error, msg) {
    exec(success, error, "IrompPlugin", "setStopSign", [msg]);
};