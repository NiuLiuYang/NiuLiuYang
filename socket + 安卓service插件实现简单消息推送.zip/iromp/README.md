## 安装&配置

    直接执行安装插件命令即可

### 调用方法

	//启动服务
	window.IrompPlugin.startServiceOnSuccess(successCallback,errorCallback,{"ip":"172.16.1.166","port":"8080","deviceId":"1234","userId":"Jack","s":"","sleep":"5000"});

	//调用成功
	function successCallback(data) {}
	//调用失败
	function errorCallback(data) {}
	
	//关闭服务
	window.IrompPlugin.stopServiceOnSuccess(successCallback,errorCallback);
	
	//为防止服务被杀死----本方法已经在启动服务的时候帮你调用了
	window.IrompPlugin.setStartSign(successCallback,errorCallback);
	
	//为了防止服务无法停止----本方法已经在停止服务的时候帮你调用了
	window.IrompPlugin.setStopSign(successCallback,errorCallback);