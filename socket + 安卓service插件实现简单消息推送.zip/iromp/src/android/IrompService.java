package com.ronhe.iromp;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;

import com.ronhe.iromp.push.client.IPushCallback;
import com.ronhe.iromp.push.client.PushClient;
import com.ronhe.iromp.push.message.DeviceType;
import com.ronhe.iromp.push.message.SysType;

import org.apache.cordova.PluginResult;
import org.json.JSONObject;
import org.apache.log4j.BasicConfigurator;

import java.util.HashMap;
import java.util.Map;

public class IrompService extends Service {

  /*手机拨号*#*#2846579#*#*，进入projectmenu--后台设置--LOG设置--LOG开关--选中所有选项；
    然后重启后，LOGCAT生效了*/
	private IRompThread iRT;
    private int index = 0;

    private Map<String,String> map = new HashMap<String, String>();

    public IrompService() {
    }

    @Override
    public IBinder onBind(Intent intent) {
        throw new UnsupportedOperationException("UnsupportedOperationException");
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
		Log.e("-------------->","onStartCommand");
        map.put("ip",intent.getStringExtra("ip"));
        map.put("port",intent.getStringExtra("port"));
        map.put("deviceId",intent.getStringExtra("deviceId"));
        map.put("userId",intent.getStringExtra("userId"));
        map.put("s",intent.getStringExtra("s"));
        map.put("sleep",intent.getStringExtra("sleep"));
        return START_STICKY;
    }

    @Override
    public void onCreate() {
        if(iRT == null){
            iRT = new IRompThread();
            iRT.setRunning(true);
        }
        iRT.start();
    }

    @Override
    public void onDestroy() {
        if(iRT != null){
            iRT.setRunning(false);
            iRT = null;
        }
        //销毁时重新启动Service
        startService();
    }

    /**
     * 启动服务
     * 登录成功开启服务
     */
    public void startService(){
        Boolean sign = SharedPrefsUtil.getValue(this, "SERVICE_SIGN", "SIGN", true);
        if(sign){
            Intent i = new Intent(this,IrompService.class);
			startService(i);
        }
    }

	/**
     * 工作线程
     */
    public class IRompThread extends Thread {

        private boolean running = false;

        public IRompThread(){}

        public void setRunning(boolean running){
            this.running = running;
        }

        @Override
        public void run() {
            super.run();
			Log.e("-------------->","执行工作线程run");
            while (running){
				Log.e((index++)+"-------》","线程名字"+this.getName());
                pushClient(map);
                try {
                    sleep(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }

  /**
   * 调用服务
   * @param map
   */
  public void pushClient(Map<String,String> map){
    BasicConfigurator.configure();
    PushClient.start(map.get("ip"), Integer.parseInt(map.get("port")), DeviceType.MOBILE, SysType.ANDORID, map.get("deviceId"), map.get("userId"), map.get("s"), new IPushCallback() {
        @Override
        public void push(String senderId, String msg) {
          /*System.out.printf("收到来自%s的通知:%s\n",senderId,msg);*/
            JSONObject json = new JSONObject();
            try{
              json.put("senderId",senderId);
              json.put("msg",msg);
            }catch (Exception e){
                e.printStackTrace();
            }
            PluginResult pluginResult = new PluginResult(PluginResult.Status.OK,json);
            //true：回调继续保持，即当前返回后后面还会有返回 false:回调结束，即当这个返回后不会再有返回
            pluginResult.setKeepCallback(true);
            IrompPlugin.callback.sendPluginResult(pluginResult);
        }
    });
    try {
        Thread.sleep(Integer.parseInt(map.get("sleep")));
    } catch (InterruptedException e) {
        e.printStackTrace();
    }
    PushClient.stop();
  }
	

}
