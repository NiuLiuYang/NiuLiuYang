package com.ronhe.iromp;

import android.content.Intent;
import android.util.Log;

import org.apache.cordova.CallbackContext;
import org.apache.cordova.CordovaPlugin;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class IrompPlugin extends CordovaPlugin {

	public static CallbackContext callback = null;

	@Override
    public boolean execute(String action, JSONArray args, CallbackContext callbackContext) throws JSONException {
		try {
            callback = callbackContext;
            //开启服务
            if(action.equals("startServiceOnSuccess")){
				  Log.e("-------------->","启动安卓服务");
				  Map<String,String> obj = getJsonError(args);
				  startServiceOnSuccess(obj);
				  //callbackContext.success(""+index);
				  return true;
            }
            //关闭服务
            if(action.equals("stopServiceOnSuccess")){
				  Log.e("-------------->","关闭服务");
				  stopServiceOnSuccess();
				  callbackContext.success("stopServiceOnSuccess");
				  return true;
            }
            //设置开启服务后防止被关闭的循环值
            if(action.equals("setStartSign")){
				  Log.e("-------------->","设置开启循环值");
				  setStartSign();
				  callbackContext.success("setStartSign");
				  return true;
            }
            //设置关闭服务的循环值
            if(action.equals("setStopSign")){
				  Log.e("-------------->","设置关闭循环值");
				  setStopSign();
				  callbackContext.success("setStopSign");
				  return true;
            }
			callbackContext.error("Invalid Action");
            return false;
        } catch (Exception e) {
            callbackContext.error(e.getMessage());
            return false;
        }
    }

  /**
   *  解析json
   * @param args
   * @return
   * @throws JSONException
     */
  public Map<String,String> getJsonError(JSONArray args) throws JSONException{
    Map<String,String> map = new HashMap<String,String>();
    for(int i = 0; i < args.length(); i++){
		  JSONObject obj = args.getJSONObject(i);
		  map.put("ip",obj.getString("ip"));
		  map.put("port",obj.getString("port"));
		  map.put("deviceId",obj.getString("deviceId"));
		  map.put("userId",obj.getString("userId"));
		  map.put("s",obj.getString("s"));
		  map.put("sleep",obj.getString("sleep"));
    }
    return map;
  }

	/**
	 * 启动服务
	 */
	public void startServiceOnSuccess(Map<String,String> obj) {
		/** Intent intent=new Intent(cordova.getActivity(), CloudService.class);
		 cordova.getActivity().getApplicationContext().bindService(intent, serviceConnection, Context.BIND_AUTO_CREATE); **/
		 SharedPrefsUtil.putValue(this.cordova.getActivity(), "SERVICE_SIGN", "SIGN", true);
		 Intent i = new Intent(this.cordova.getActivity(), IrompService.class);
		 i.putExtra("ip",obj.get("ip"));
		 i.putExtra("port",obj.get("port"));
		 i.putExtra("deviceId",obj.get("deviceId"));
		 i.putExtra("userId",obj.get("userId"));
		 i.putExtra("s",obj.get("s"));
		 i.putExtra("sleep",obj.get("sleep"));
		 this.cordova.getActivity().getApplicationContext().startService(i);
	}

	/**
	 * 关闭服务
	 */
	public void stopServiceOnSuccess(){
		SharedPrefsUtil.putValue(this.cordova.getActivity(), "SERVICE_SIGN", "SIGN", false);
        this.cordova.getActivity().getApplicationContext().stopService(new Intent(this.cordova.getActivity(),IrompService.class));
    }

	/**
     * 设置标识
     * 登录成功的时候调用
     */
    public void setStartSign(){
        SharedPrefsUtil.putValue(this.cordova.getActivity(), "SERVICE_SIGN", "SIGN", true);
    }

    /**
     * 修改标识
     * 登出成功的时候调用
     */
    public void setStopSign(){
        SharedPrefsUtil.putValue(this.cordova.getActivity(), "SERVICE_SIGN", "SIGN", false);
    }

}
