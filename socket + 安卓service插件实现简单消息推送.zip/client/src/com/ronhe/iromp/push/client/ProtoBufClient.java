package com.ronhe.iromp.push.client;

import com.ronhe.iromp.push.message.*;
import io.netty.bootstrap.Bootstrap;
import io.netty.channel.*;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioSocketChannel;
import io.netty.handler.codec.protobuf.ProtobufDecoder;
import io.netty.handler.codec.protobuf.ProtobufEncoder;
import io.netty.handler.codec.protobuf.ProtobufVarint32FrameDecoder;
import io.netty.handler.codec.protobuf.ProtobufVarint32LengthFieldPrepender;
import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Logger;
import org.apache.log4j.net.SyslogAppender;

/**
 * Created by yushunan on 2017/7/10.
 */
class ProtoBufClient {
    private static Logger log = Logger.getLogger(ProtoBufClient.class);
    private static Bootstrap b=null;
    private static ChannelFuture f = null;
    private static EventLoopGroup group = null;
    private static String host;
    private static IPushCallback push;
    private static String deviceId;
    private static String userId;

    private static int port;

//    public static void reconnect(){
//        stop();
//        connect(port,host,deviceId,userId,push);
////        if(null != b){
////            try {
////                f = b.connect(host,port).sync();
////            } catch (InterruptedException e) {
////                log.error("Connect push server error",e);
////            }
////        }
//    }
    public static void connect(int port, String host, final String deviceId, final String userId,final IPushCallback push)  {
        ProtoBufClient.host = host;
        ProtoBufClient.port = port;
        ProtoBufClient.deviceId = deviceId;
        ProtoBufClient.userId = userId;
        ProtoBufClient.push = push;
        // 配置客户端NIO线程组
        group = new NioEventLoopGroup();

        //try {
        b = new Bootstrap();
        b.group(group).channel(NioSocketChannel.class).option(ChannelOption.TCP_NODELAY, true)
                .handler(new ChannelInitializer<SocketChannel>() {
                    @Override
                    public void initChannel(SocketChannel ch) throws Exception {
                        ch.pipeline().addLast(new ProtobufVarint32FrameDecoder());
                        ch.pipeline().addLast(new ProtobufDecoder(ResponseProto.Response.getDefaultInstance()));
                        ch.pipeline().addLast(new ProtobufVarint32LengthFieldPrepender());
                        ch.pipeline().addLast(new ProtobufEncoder());
                        ch.pipeline().addLast(new ProtoBufClientHandler(deviceId, userId, push));
                    }
                });
        //b.connect(host,port);
        while (true) {
            try {
                f = b.connect(host, port);
                f.sync();
                break;
                // 等待客户端链路关闭
                //f.channel().closeFuture().sync();
            } catch (Exception ex) {
                log.error("Connect push server error", ex);
                try {
                    Thread.sleep(PushClient.RECONNECT_INTERVAL);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

            }
        }
    }

    public static void disconnect(){
        if(null != f){
            try {
                f.channel().close();
                f.channel().closeFuture().sync();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }finally {
                group.shutdownGracefully();
            }
        }
    }
    public static void stop(){
        disconnect();

        group=null;
        f=null;
        b=null;
    }

    /**
     * @param args
     * @throws Exception
     */
    public static void main(String[] args) throws Exception {
        BasicConfigurator.configure();
        int port = 8080;
        if (args != null && args.length > 0) {
            try {
                port = Integer.valueOf(args[0]);
            } catch (NumberFormatException e) {
                // 采用默认值
            }
        }
        final int port2 = port;
        for(int i=0;i<500;i++){
            final  int j=i;
            new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        ProtoBufClient.connect(port2, "127.0.0.1", String.valueOf(j), "Tom", new IPushCallback() {
                            @Override
                            public void push(String senderId, String msg) {
                                System.out.printf("receive message from %s:%s",senderId,msg);
                            }
                        });
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }).start();

        }

        //ProtoBufClient.connect(port, "127.0.0.1","4321","Jack");

    }
}
