package com.ronhe.iromp.push.client;

/**
 * Created by nan on 17/7/12.
 */
public interface IPushCallback {
    void push(String senderId,String msg);
}
