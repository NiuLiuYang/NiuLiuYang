package com.ronhe.iromp.push.client;

import com.ronhe.iromp.push.message.DeviceType;
import com.ronhe.iromp.push.message.SysType;
import org.apache.log4j.BasicConfigurator;

/**
 * Created by pc on 2017/7/12.
 */
public class TestPushClient {
    public static void main(String[] args) {
        BasicConfigurator.configure();
        PushClient.start("127.0.0.1", 8899, DeviceType.MOBILE, SysType.ANDORID, "1234", "Jack", "", new IPushCallback() {
            @Override
            public void push(String senderId, String msg) {
                System.out.printf("收到来自%s的通知:%s\n",senderId,msg);
            }
        });
        try {
            Thread.sleep(500*1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println("before stop");
        PushClient.stop();
        System.out.println("after stop");


    }
}
