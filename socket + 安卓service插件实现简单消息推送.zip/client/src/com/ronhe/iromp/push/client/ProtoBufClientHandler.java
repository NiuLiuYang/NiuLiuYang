package com.ronhe.iromp.push.client;

import com.ronhe.iromp.push.message.*;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInboundHandlerAdapter;
import org.apache.log4j.Logger;


/**
 * Created by yushunan on 2017/7/10.
 */
class ProtoBufClientHandler extends ChannelInboundHandlerAdapter {
    private String deviceId;
    private String userId;
    private IPushCallback push;
    private static Object heartbeatLock = new Object();
    private static final Logger log  = Logger.getLogger(ProtoBufClientHandler.class);

    ProtoBufClientHandler(String deviceId,String userId, IPushCallback push){
        log.debug(String.format("instance init:%d",this.hashCode()));
        this.deviceId=deviceId;
        this.userId=userId;
        this.push = push;
    }
    @Override
    public void channelActive(final ChannelHandlerContext ctx) {

        login(ctx);
//        new Thread(new Runnable() {
//            @Override
//            public void run() {
//                while(true){
//                    try {
//                        Thread.sleep(1000);
//                    } catch (InterruptedException e) {
//                        e.printStackTrace();
//                    }
//                    ctx.writeAndFlush(req);
//                }
//            }
//        }).start();
    }
    private void login(final ChannelHandlerContext ctx){
        log.debug(String.format("instance in login:%d",this.hashCode()));
        ReqBaseProto.Req.Builder bb = ReqBaseProto.Req.newBuilder();
        bb.setReqType(ReqType.LOGIN.getValue());

        ReqLoginProto.Req.Builder bs = ReqLoginProto.Req.newBuilder();
        bs.setDeviceId(this.deviceId);
        bs.setUserId(this.userId);
        bs.setSysType(SysType.IOS.getValue());

        bb.setPackage(bs.build().toByteString());

        ctx.writeAndFlush(bb.build());


    }

    public void heartbeat(final ChannelHandlerContext ctx) {
        //synchronized (heartbeatLock){
            ReqBaseProto.Req.Builder bb = ReqBaseProto.Req.newBuilder();
            bb.setReqType(ReqType.HEARTBEAT.getValue());

            ReqHeartbeatProto.Req.Builder bs = ReqHeartbeatProto.Req.newBuilder();
            bs.setDeviceId(this.deviceId);
            bs.setUserId(this.userId);
            bs.setSysType(SysType.IOS.getValue());

            bb.setPackage(bs.build().toByteString());

            ctx.writeAndFlush(bb.build());
        //}


    }


    @Override
    public void channelRead(final ChannelHandlerContext ctx, Object msg) throws Exception {
        ResponseProto.Response res = (ResponseProto.Response)msg;

        //maybe receive response or push

        log.debug(String.format("instance:%d reqType:%s error code:%d message:%s senderId:%s msg:%s\n",this.hashCode()
                ,ReqType.forNumber(res.getReqType()),res.getRetCode(),res.getRetMsg(),res.getSenderId(),res.getMsg()
        ));

        if(res.getReqType()==ReqType.LOGIN.getValue())
        {
            if(0==res.getRetCode()) {
                log.info("---login push server success!");
                PushClient.setStart(true);

                Thread t = new Thread(new Runnable() {
                    @Override
                    public void run() {

                        while (true) {
                            try {
                                Thread.sleep(PushClient.HEARTBEAT_INTERVAL);
                            } catch (InterruptedException e) {
                                if (PushClient.isBeginStop())
                                    break;
                                e.printStackTrace();
                            }
                            if (PushClient.isBeginStop()) break;
                            heartbeat(ctx);
                        }
                        log.info("---heartbeat thread stop!");
                    }
                });
                t.start();
                PushClient.setHeartbeatThread(t);
            }else{
                log.fatal(String.format("login push server fail retCode:%d retMsg:%s",res.getRetCode(),res.getRetMsg()));
                //login fail ,disconnect

                ProtoBufClient.stop();


            }

        }else if(res.getReqType()==ReqType.PUSH.getValue()){

            this.push.push(res.getSenderId() ,res.getMsg() );
        }

    }



    @Override
    public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) {
        //synchronized (heartbeatLock){
            log.error("---communication error",cause);
            ctx.close();

//        try {
//            Thread.sleep(5*1000);
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }

            PushClient.restart();
            //cause.printStackTrace();
        //}

    }


}
