package com.ronhe.iromp.push.client;

import com.ronhe.iromp.push.message.DeviceType;
import com.ronhe.iromp.push.message.SysType;

/**
 * Created by yushunan on 2017/7/12.
 */
public class PushClient {
    public static final int HEARTBEAT_INTERVAL = 2*1000;
    public static final int RECONNECT_INTERVAL = 10*1000;
    private static SysType sysType;
    private static String deviceId;
    private static String userId;
    private static String s;
    private static IPushCallback push;
    private static DeviceType deviceType;
    private static String host;
    private static int port;
    private static boolean started = false;
    private static boolean beginStop = false;

    public static void setHeartbeatThread(Thread heartbeatThread) {
        PushClient.heartbeatThread = heartbeatThread;
    }

    private static Thread heartbeatThread= null;
    public static void start(String host,int port,DeviceType deviceType ,SysType sysType , String deviceId, String userId, String s, IPushCallback push){
        if(started) return;
        PushClient.deviceId = deviceId ;
        PushClient.sysType = sysType;
        PushClient.userId = userId;
        PushClient.s = s;
        PushClient.push = push;
        PushClient.host = host;
        PushClient.port = port;
        PushClient.deviceType = deviceType;
        try {
            ProtoBufClient.connect(port,host,deviceId ,userId ,push);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
    public static void stop(){
        beginStop = true;
        if(null != heartbeatThread){
            heartbeatThread.interrupt();
            try {
                heartbeatThread.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            heartbeatThread=null;
        }

        ProtoBufClient.stop();

        beginStop = false;
        started = false;


    }
    public static void restart(){
        stop();
        start( host, port, deviceType , sysType ,  deviceId,  userId,  s,  push);
    }

    public static boolean isBeginStop() {
        return beginStop;
    }

    public static boolean isStart() {
        return started;
    }

    public static void setStart(boolean start) {
        PushClient.started = start;
    }


}
