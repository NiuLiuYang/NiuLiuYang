package com.ronhe.iromp.push.client;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

/**
 * Created by yushunan on 2017/7/10.
 */
public class SocketClient {
    public static void main(String[] args) {

        try {
            Socket socket=new Socket("127.1.1.1",8080);
            //send client info (userId,clientType,deviceId)
            BufferedReader br = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            //br.readLine()

            PrintWriter printWriter = new PrintWriter(socket.getOutputStream(), true);
            printWriter.println("hi");
            printWriter.flush();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
