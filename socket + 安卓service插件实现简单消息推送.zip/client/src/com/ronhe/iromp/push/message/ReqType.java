package com.ronhe.iromp.push.message;

/**
 * Created by pc on 2017/7/11.
 */
public enum ReqType {
    LOGIN(1) ,
    HEARTBEAT(2) ,
    LOGOUT(3) ,
    PUSH(4);

    private final int value;

    ReqType(int value) {
        this.value = value;
    }
    public int getValue(){
        return this.value;
    }

//    public static ReqType valueOf(int value) {
//        return forNumber(value);
//    }

    public static ReqType forNumber(int value) {
        switch (value) {
            case 1: return LOGIN;
            case 2: return HEARTBEAT;
            case 3: return LOGOUT;
            case 4: return PUSH;
            default: return null;
        }
    }
}
