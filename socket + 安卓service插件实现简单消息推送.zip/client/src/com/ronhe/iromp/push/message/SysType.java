package com.ronhe.iromp.push.message;

/**
 * Created by pc on 2017/7/11.
 */
public enum SysType {
    IOS(1) ,
    ANDORID(2);

    private final int value;

    SysType(int value) {
        this.value = value;
    }
    public int getValue(){
        return this.value;
    }

//    public static ReqType valueOf(int value) {
//        return forNumber(value);
//    }

    public static SysType forNumber(int value) {
        switch (value) {
            case 1: return IOS;
            case 2: return ANDORID;
            default: return null;
        }
    }
}
