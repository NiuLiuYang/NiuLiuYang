package com.ronhe.iromp.push.message;

/**
 * Created by nan on 17/7/12.
 */
public enum DeviceType {
    MOBILE,
    PLAT
}
