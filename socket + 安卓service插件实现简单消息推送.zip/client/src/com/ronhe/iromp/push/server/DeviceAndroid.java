package com.ronhe.iromp.push.server;

import com.ronhe.iromp.push.message.ReqType;
import com.ronhe.iromp.push.message.ResponseProto;
import io.netty.channel.ChannelHandlerContext;

/**
 * Created by pc on 2017/7/6.
 */
public class DeviceAndroid extends Device {
    private ChannelHandlerContext ctx = null;
    DeviceAndroid(String userId,String deviceId,ChannelHandlerContext ctx){
        super(userId,deviceId);
        this.ctx = ctx;
    }

    @Override
    public void push(String showText,String senderId) {
        ResponseProto.Response.Builder bb = ResponseProto.Response.newBuilder();
        bb.setReqType(ReqType.PUSH.getValue());

        bb.setSenderId(senderId);
        bb.setMsg(showText );

        ctx.writeAndFlush(bb.build());
    }

    @Override
    public void offline() {

    }

}
