package com.ronhe.iromp.push.server;

import com.ronhe.iromp.push.message.*;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInboundHandlerAdapter;
import org.apache.log4j.Logger;

/**
 * Created by pc on 2017/7/10.
 */
public class ProtoBufServerHandler extends ChannelInboundHandlerAdapter {
    private static Logger log = Logger.getLogger(ProtoBufServerHandler.class);
    @Override
    public void channelRead(ChannelHandlerContext ctx, Object msg) throws Exception {
        ReqBaseProto.Req req = (ReqBaseProto.Req) msg;
        log.debug(String.format("reqType:%s\n",req.getReqType()));
        //ReqBaseProto.Req.ReqType.LGOIN
        switch (ReqType.forNumber(req.getReqType())){
            case LOGIN:
                serviceLogIn(ctx,ReqLoginProto.Req.parseFrom(req.getPackage()));
                break;
            case HEARTBEAT:
                serviceHeartbeat(ctx,ReqHeartbeatProto.Req.parseFrom(req.getPackage()));
                break;
            case LOGOUT:
                serviceLogout(ctx,ReqLogoutProto.Req.parseFrom(req.getPackage()));
                break;
            case PUSH:
                servicePush(ctx,ReqPushProto.Req.parseFrom(req.getPackage()));
                break;
            default:
                break;
        }

        //ctx.writeAndFlush(buildResponse(0,"ok"));

    }

    private void testPush2Mobile(final ChannelHandlerContext ctx){
        new Thread(new Runnable() {
            @Override
            public void run() {
                while (true){
                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    push(ctx, "888", "hello mobile!");
                }
            }
        }).start();
    }
    private void push(ChannelHandlerContext ctx,String senderId,String msg){
        ResponseProto.Response.Builder bb = ResponseProto.Response.newBuilder();
        bb.setReqType(ReqType.PUSH.getValue());

        bb.setSenderId(senderId);
        bb.setMsg(msg);

        ctx.writeAndFlush(bb.build());
    }
    private void serviceLogIn(ChannelHandlerContext ctx ,ReqLoginProto.Req req){
        log.debug(String.format("Login:deviceId:%s userId:%s sysType:%s\n",req.getDeviceId(),req.getUserId(), SysType.forNumber(req.getSysType())));
        //System.out.printf("Login:deviceId:%s userId:%s sysType:%s\n",req.getDeviceId(),req.getUserId(), SysType.forNumber(req.getSysType()));

        //TODO:check s

        if(req.getSysType() == SysType.ANDORID.getValue())
            PushManager.registerAndroidDevice( req.getUserId(),req.getDeviceId() ,ctx);
        else if(req.getSysType() == SysType.IOS.getValue()){
            PushManager.registerIosDevice( req.getUserId(),req.getDeviceId(), req.getIosToken());
        }else
        {
            ctx.writeAndFlush(buildResponse(ReqType.LOGIN.getValue(),2,"unknown sysType"));
            log.error("unknown sysType");
            return;
        }


        ctx.writeAndFlush(buildResponse(ReqType.LOGIN.getValue(),0,"ok"));

        testPush2Mobile(ctx);

    }

    private void serviceHeartbeat(ChannelHandlerContext ctx ,ReqHeartbeatProto.Req req){
        log.debug(String.format("Heartbeat:deviceId:%s userId:%s sysType:%s\n",req.getDeviceId(),req.getUserId(),SysType.forNumber(req.getSysType())));
        //TODO:REG LAST HEARBEAT TIME

        ctx.writeAndFlush(buildResponse(ReqType.HEARTBEAT.getValue(),0,"ok"));
    }
    private void serviceLogout(ChannelHandlerContext ctx ,ReqLogoutProto.Req req){
        log.debug(String.format("Heartbeat:deviceId:%s userId:%s sysType:%s\n",req.getDeviceId(),req.getUserId(),SysType.forNumber(req.getSysType())));

        PushManager.unregisterDevice(req.getUserId(),req.getDeviceId());
        ctx.writeAndFlush(buildResponse(ReqType.LOGOUT.getValue(),0,"ok"));
    }

    private void servicePush(ChannelHandlerContext ctx ,ReqPushProto.Req req){
        log.debug(String.format("Push:senderId:%s receiverId:%s msg:%s\n",req.getSenderId(),req.getSenderId(),req.getMsg()));
        PushManager.push(req.getReceiverId() ,req.getSenderId() ,req.getMsg() );

        ctx.writeAndFlush(buildResponse(ReqType.PUSH.getValue(),0,"ok"));
    }

    private ResponseProto.Response buildResponse(int reqType,int retCode,String message){
        ResponseProto.Response.Builder builder = ResponseProto.Response.newBuilder();
        builder.setReqType(reqType);
        builder.setRetCode(retCode);
        builder.setRetMsg(message);

        return builder.build();
    }


    @Override
    public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) {
        log.error("---",cause);
        //cause.printStackTrace();
        ctx.close();
    }
}
