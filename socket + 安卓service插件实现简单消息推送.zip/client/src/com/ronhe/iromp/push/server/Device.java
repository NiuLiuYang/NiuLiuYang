package com.ronhe.iromp.push.server;

/**
 * Created by yushunan on 2017/7/6.
 */
public abstract class Device{
    private String userId = null;
    private String deviceId = null;
    private Device(){}
    public Device(String userId,String deviceId) {
        this.userId = userId;
        this.deviceId = deviceId;
    }
    /**
     * Push message to this Device
     * @param showText
     */
    abstract void push(String showText,String senderId);

    /**
     * Push offline notificaton and close resource.
     */
    abstract void offline();


    public String getDeviceId() {
        return deviceId;
    }


    public String getUserId() {
        return userId;
    }
}
