package com.ronhe.iromp.push.server;

import io.netty.channel.ChannelHandlerContext;

import java.nio.channels.SocketChannel;
import java.util.AbstractMap;

import java.util.concurrent.ConcurrentHashMap;

/**
 * Created by yushunan on 2017/7/6.
 */
public class PushManager {
    private static AbstractMap<String,Device> devices = new ConcurrentHashMap<String, Device>(1000);
    //To permit pc and mobile device using push function at the same time ,just add another map for pc.

    public static void registerAndroidDevice(String userId,String deviceId,ChannelHandlerContext ctx){
        devices.put(userId,new DeviceAndroid(userId,deviceId,ctx));
    }
    public static void registerIosDevice(String userId,String deviceId,String deviceToken){
        devices.put(userId,new DeviceIos(userId,deviceId,deviceToken));
    }
    public static void push(String userId,String senderId,String showContent){
        Device dev = devices.get(userId);
        if(null != dev){
            dev.push(showContent,senderId);
        }
    }
    public static void unregisterDevice(String userId,String deviceId){
        Device dev = devices.get(userId);
        if(null != dev){
            if(dev.getDeviceId()==deviceId){
                devices.remove(userId);
            }
        }
    }
}
