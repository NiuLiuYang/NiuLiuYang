package com.ronhe.iromp.push.server;

/**
 * Created by pc on 2017/7/6.
 */
public class DeviceIos extends Device {
    private String token = null;
    DeviceIos(String userId,String deviceId,String token){
        super(userId,deviceId);
        this.token = token;
    }
    @Override
    public void push(String showText ,String senderId) {
        //TODO:Push to apns server
    }

    @Override
    public void offline() {

    }
}
